# G'Ram Chai Cafe — Firebase-connected web app

This package keeps the existing G'Ram Chai Cafe look and the 51-item menu, and replaces local-only demo orders with Firebase Firestore orders and an admin dashboard.

## Firebase project configured
- Project ID: `g-ram-chai-cafe`
- Firestore: `(default)` / `asia-south1`
- Collection: `orders`
- Admin UID allowlist: `ShEiWctHT3VnVlXj2Kg7MXOImZM2`
- Firebase Web SDK: compat 10.12.2 (loaded from Google's CDN)

## Included files
- `index.html` — customer menu, cart, checkout, Firebase order submission, email/password admin sign-in and live order dashboard.
- `firestore.rules` — public order creation; admin-only order reads, status changes and deletes.

## Important setup checks before public launch
1. In Firebase Authentication, confirm Email/Password is enabled and the admin account's UID is exactly the allowlisted UID above.
2. Confirm the admin account email/password can sign in. Do not put the password in this package or share it in chat.
3. Publish `firestore.rules` in Firestore Rules only after comparing with your current rules. These rules intentionally allow unauthenticated customer order creation and admin-only reads/updates. Public create endpoints can be abused; add Firebase App Check and consider a trusted server-side price/abuse-control layer before broad public launch.
4. In Authentication > Settings > Authorized domains, ensure the eventual Hosting domain is listed. Firebase Hosting default domains are normally `g-ram-chai-cafe.web.app` and `g-ram-chai-cafe.firebaseapp.com`.
5. Deploy `index.html` to Firebase Hosting. This package is not deployed automatically.

## Business logic
- Packing: ₹10 when cart is non-empty.
- Delivery: ₹10 for Delivery orders; customer confirms they believe the address is within 2 km. Cafe must still verify delivery availability.
- Pickup: no delivery fee.
- Payment: Cash or UPI at the cafe / as arranged; no payment gateway is integrated.
- Ice creams and cool drinks are not included.
- Order status: New, Accepted, Preparing, Ready, Completed, Rejected.

## Testing
First place a small test order from the customer view. Then sign in through Admin with the authorized Firebase email/password account and verify that the order appears and status changes sync. Do not use real customer traffic until the test passes.
